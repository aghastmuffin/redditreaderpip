from setuptools import setup, Extension, find_packages
from Cython.Build import cythonize

extensions = [
    Extension("reddit_reader", sources=["RedditReader.pyx"]),
]
setup(
    name='reddit_reader',
    ext_modules=cythonize(extensions, compiler_directives={'language_level': "3"}),
    packages=find_packages(),  # Automatically find packages
    package_data={
        'reddit_reader': ['assets/*'],  # Include all files in the assets directory
    },
    include_package_data=True,  # Ensure package_data is included
)